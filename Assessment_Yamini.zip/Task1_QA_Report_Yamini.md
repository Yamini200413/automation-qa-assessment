# Task 1 worksheet - fill this in from YOUR OWN testing of https://demo.realworld.io

Only log what you actually saw. Take a screenshot for each one.

## Flows to run (in order)
1. Sign up (try: empty fields, duplicate email, weak/short password, invalid email format)
2. Log in (wrong password, then correct) / log out / refresh while logged in
3. Create article (empty title, 5000+ char body, emoji/special chars, `<script>alert(1)</script>` in title/body)
4. Edit article, then delete it. Check the feed and profile update.
5. Comments, favorites, follow/unfollow, tags, pagination
6. DevTools -> Network: throttle to "Slow 3G", check error messages, status codes, and console errors
7. Keyboard-only navigation, Lighthouse accessibility audit, mobile viewport (375px)
8. Log in on two tabs, log out in one, act in the other (stale session)

## Bug table (one row per issue)
| # | Title / Summary | Steps to Reproduce | Expected vs Actual | Severity | Suspected Cause |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
| 5 | | | | | |

## Root-cause analysis (pick ONE, 5-10 sentences)
- What is happening (user-visible symptom):
- Why (frontend / API / data / config layer, with evidence from DevTools):
- How I'd fix it:
- How I'd prevent it (test, validation, monitoring):
