# Task 2 - n8n "Morning Brief" workflow

**What it does:** every hour, fetches the most-starred GitHub repos tagged `n8n`, keeps the top 5, enriches the #1 repo with its README, and posts a digest to Discord.

**APIs used**
- GitHub Search API (`/search/repositories?q=topic:n8n&sort=stars`) - free, no key needed for light use, stable JSON.
- GitHub README endpoint (`/repos/{owner}/{repo}/readme`) - second endpoint of the same API, used to enrich the top item.
- Discord webhook - free, quick to set up, and the webhook URL lives in n8n's Credentials store.

**Transformation (Code node "Top 5"):** sorts by `stargazers_count`, keeps 5, reduces each repo to name / stars / url / description / language. "Build Digest" then formats a Discord message (under 2000 chars) with a 300-char README preview.

**IF branch:** if the top repo has more than 1000 stars, the message is sent with a "HOT" prefix; otherwise a normal prefix. 1000 was chosen as a simple "well-established project" threshold.

**Error path:** the two HTTP nodes retry (3 and 2 tries) and use "On Error -> continue (using error output)". If the repo search or the Code node fails, the error goes to "Format Error" -> Discord error alert, so nothing fails silently. If only the README call fails, "README Fallback" inserts "(README unavailable)" and the digest still ships.

**Setup:** import the JSON, create a *Discord Webhook* credential, select it on the three Discord nodes, run once manually, then activate.
